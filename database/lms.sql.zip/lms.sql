-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2020 at 03:26 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `book_image` varchar(250) NOT NULL,
  `book_author_name` varchar(100) NOT NULL,
  `book_publication_name` varchar(100) NOT NULL,
  `book_purchase_date` varchar(100) NOT NULL,
  `book_price` varchar(100) NOT NULL,
  `book_quantity` int(11) NOT NULL,
  `available_quantity` int(11) NOT NULL,
  `libraian_username` varchar(100) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `book_name`, `book_image`, `book_author_name`, `book_publication_name`, `book_purchase_date`, `book_price`, `book_quantity`, `available_quantity`, `libraian_username`, `datetime`) VALUES
(11, 'বাসর', 'basor.jpg', 'হুমায়ন আহমেদ', 'আদিকাল', '2019-03-04', '220', 45, 14, 'imran007', '2019-10-16 16:53:00'),
(12, 'ক্রান্তিকাল', 'krantikal.jpg', 'প্রফুল্ল রায়', 'সূর্য', '15-04-18', '320', 30, 12, 'imran007', '2019-10-16 16:53:58'),
(13, 'General Anatomy', 'generalAnatomy.jpg', 'B D chaurasia', 'text', '2018-03-07', '620', 20, 12, 'imran007', '2019-10-21 14:31:19'),
(14, 'Genetics', 'genetics.jpeg', 'B D Singh', 'singh publication ', '2018-06-11', '550', 15, 8, 'imran007', '2019-10-21 14:32:31'),
(15, 'পদার্থবিজ্ঞান', 'podarthoBiggan.jpg', 'সাহা', 'জয়কলি', '2014-02-02', '180', 90, 87, 'imran007', '2019-10-21 14:33:41');

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `id` int(5) NOT NULL,
  `student_id` int(5) NOT NULL,
  `book_id` int(5) NOT NULL,
  `book_issue_date` varchar(20) NOT NULL,
  `book_return_date` varchar(20) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`id`, `student_id`, `book_id`, `book_issue_date`, `book_return_date`, `datetime`) VALUES
(1, 2, 12, '17-10-19', '22-10-19', '2019-10-17 18:35:44'),
(2, 36, 11, '17-10-19', '14-11-19', '2019-10-17 18:40:09'),
(3, 2, 14, '21-10-19', '22-10-19', '2019-10-21 15:14:26'),
(4, 2, 13, '22-10-19', '22-10-19', '2019-10-22 03:34:22'),
(5, 2, 14, '22-10-19', '22-10-19', '2019-10-22 03:35:07');

-- --------------------------------------------------------

--
-- Table structure for table `libraian`
--

CREATE TABLE `libraian` (
  `id` int(3) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `libraian`
--

INSERT INTO `libraian` (`id`, `first_name`, `last_name`, `email`, `username`, `password`, `datetime`) VALUES
(1, 'Imran', 'hasan', 'imran@gmail.com', 'imran007', '81dc9bdb52d04dc20036dbd8313ed055', '2019-10-08 18:40:51');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `roll` int(6) NOT NULL,
  `reg_no` int(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `image` varchar(100) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `last_name`, `roll`, `reg_no`, `email`, `username`, `password`, `phone`, `image`, `status`, `datetime`) VALUES
(2, 'Imran', 'Hasan', 96789, 7289, 'imran@gmail.com', 'imran007', '81dc9bdb52d04dc20036dbd8313ed055', '01774441359', NULL, 1, '2019-10-06 20:30:33'),
(36, 'Easin', 'Ahmed', 445566, 7228, 'easin@info.com', 'easin55', '81dc9bdb52d04dc20036dbd8313ed055', '01775466135', NULL, 1, '2019-10-08 05:51:17'),
(37, 'Lokman', 'Hosen', 456789, 7286, 'lokman@gmail.com', 'lokman007', '81dc9bdb52d04dc20036dbd8313ed055', '01775466135', NULL, 0, '2019-10-08 05:54:23'),
(38, 'Himel', 'Ahmed', 456789, 7289, 'himel@gmail.com', 'himel007', '81dc9bdb52d04dc20036dbd8313ed055', '01774441359', NULL, 1, '2019-10-08 05:58:42'),
(42, '', '', 0, 0, '', '', '', '', NULL, 0, '2019-10-23 08:24:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `libraian`
--
ALTER TABLE `libraian`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `libraian`
--
ALTER TABLE `libraian`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
